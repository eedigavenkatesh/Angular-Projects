---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: derisen

---

Please follow the issue template below. Failure to do so will result in a delay in answering your question.

## Library

- [ ] `@azure/msal-angular@0.x.x`
- [ ] `@azure/msal-angular@1.x.x`
- [ ] `@azure/msal-angular@2.x.x`

## Description
