# CHANGELOG

## 10/23/2020

* Updated msal.js to 1.4.2
* Updated M.I.W to 1.2

## 08/27/2020

* Updated msal.js to 1.4.0 and msal-angular to 1.1.1.
* Resolved implicit flow check issue in automatic registration (ps script).
* Resolved favicon loading issue.

## 08/05/2020

* Updated msal.js to 1.3.3.
* Added issue & PR templates.
* Minor README corrections.

## 06/11/2020

* Updated msal-core to 1.3.2.
* Updated Microsoft.Identity.Web to 0.1.4.
* Improved "TodoItem.cs" model to use auto generated IDs.
* Improved "todo.service.ts" to supplant trailing '/' for API calls.

## 05/19/2020

* Updated msal-core to 1.3.0 and msal-angular to 1.0.0.

## 04/06/2020

* Initial version of sample application and related files.
