import { Component } from '@angular/core';
import { NavbarComponent } from '../navbar/navbar.component';

import { Router } from '@angular/router';
import { MsalService } from '@azure/msal-angular';
import { JsonPipe } from '@angular/common';

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { apiConfig, loginRequest } from '../auth-config';

@Component({
  selector: 'app-home',
  imports: [NavbarComponent, JsonPipe],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css',
})
export class HomeComponent {
  apiData: any = null;
  constructor(
    private msalService: MsalService,
    private router: Router,
    private http: HttpClient
  ) {}

  logout() {
    // Clear localStorage
    localStorage.clear();
    this.msalService.logoutRedirect({
      postLogoutRedirectUri: 'http://localhost:4200',
    });
  }
  fetchData() {
    debugger;
    this.msalService.acquireTokenSilent(loginRequest).subscribe({
      next: (result) => {
        const headers = new HttpHeaders({
          Authorization: `Bearer ${result.accessToken}`,
        });
        debugger;
        this.http.get(apiConfig.resourceUri, { headers }).subscribe({
          next: (data) => (this.apiData = data),
          error: (err) => (this.apiData = `API error: ${err.message}`),
        });
      },
      error: (err) => {
        this.apiData = `Token acquisition error: ${err.message}`;
      },
    });
  }
}
