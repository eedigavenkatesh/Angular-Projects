import { Component } from '@angular/core';
import { MsalService } from '@azure/msal-angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  imports: [],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
})
export class LoginComponent {
  constructor(private msalService: MsalService, private router: Router) {}

  login() {
    this.msalService.loginRedirect();
  }

  ngOnInit() {
    this.msalService.instance.handleRedirectPromise().then((result) => {
      if (result?.account) {
        debugger;
        this.msalService.instance.setActiveAccount(result.account);
        this.router.navigate(['/home']);
      }
    });
  }
}
