import { Configuration, BrowserCacheLocation } from '@azure/msal-browser';

export const msalConfig: Configuration = {
  auth: {
    clientId: 'a527481d-4f6d-4e8a-898d-ad19b6c24c51', // Replace with your Azure AD app client ID
    authority:
      'https://login.microsoftonline.com/a771df68-7b47-4be0-b11c-f7ae2499c1cd', // Or 'common'
    redirectUri: 'http://localhost:4200/', // Must match redirect URI configured in Azure portal
  },
  cache: {
    cacheLocation: BrowserCacheLocation.LocalStorage,
    storeAuthStateInCookie: false,
  },
};

export const loginRequest = {
  scopes: ['api://d2e11030-66c9-44f5-a7f2-3f1197bf1926/access_as_user'], // API scope configured in Azure
};

export const apiConfig = {
  resourceUri: 'http://localhost:5006/WeatherForecast', // Your Web API endpoint
};
