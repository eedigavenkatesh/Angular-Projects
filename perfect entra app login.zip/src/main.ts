import { bootstrapApplication } from '@angular/platform-browser';
import { provideRouter } from '@angular/router';
import { importProvidersFrom } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app/app.component';
import { routes } from './app/app.routes';
import { MsalGuardConfiguration } from '@azure/msal-angular';
import { MsalInterceptorConfiguration } from '@azure/msal-angular';

import {
  MsalModule,
  MsalRedirectComponent,
  MsalService,
  MsalGuard,
} from '@azure/msal-angular';

import { PublicClientApplication, InteractionType } from '@azure/msal-browser';
import { msalConfig, loginRequest } from './app/app.config';

// Create MSAL instance
const msalInstance = new PublicClientApplication(msalConfig);

// Factory functions for MSAL config
export function MSALInstanceFactory() {
  return msalInstance;
}

export function MSALGuardConfigFactory(): MsalGuardConfiguration {
  return {
    interactionType: InteractionType.Redirect, // Use enum member explicitly
    authRequest: loginRequest,
  };
}

export function MSALInterceptorConfigFactory(): MsalInterceptorConfiguration {
  return {
    interactionType: InteractionType.Redirect, // Use enum member explicitly
    protectedResourceMap: new Map<string, Array<string>>(), // Proper type parameters
  };
}

// Async bootstrap to await MSAL initialization
async function bootstrap() {
  await msalInstance.initialize();

  bootstrapApplication(AppComponent, {
    providers: [
      provideRouter(routes),
      HttpClientModule,
      importProvidersFrom(
        MsalModule.forRoot(
          MSALInstanceFactory(),
          MSALGuardConfigFactory(),
          MSALInterceptorConfigFactory()
        )
      ),
      MsalService,
      MsalGuard,
      MsalRedirectComponent,
    ],
  });
}

bootstrap();
