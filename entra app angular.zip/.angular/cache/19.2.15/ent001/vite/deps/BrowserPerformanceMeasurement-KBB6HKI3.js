import {
  BrowserPerformanceMeasurement
} from "./chunk-5CL7ZVVJ.js";
import "./chunk-35ENWJA4.js";
export {
  BrowserPerformanceMeasurement
};
