import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-failed',
  imports: [CommonModule],
  template: `<p>Login failed. Please try again.</p>`,
  styleUrl: './failed.component.css',
})
export class FailedComponent {}
